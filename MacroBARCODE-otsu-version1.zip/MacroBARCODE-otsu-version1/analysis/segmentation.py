import csv
import os
from typing import Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
from scipy import ndimage
from skimage import filters, measure, morphology

from core import OpticalFlowConfig, ReaderConfig, SegmentationConfig, SegmentationResults, WriterConfig
from utils import find_analysis_frames, groupAvg, vprint
from utils.setup import setup_csv_writer


PER_FRAME_HEADERS = [
    "Frame",
    "Threshold",
    "Total Material Area",
    "Material Area Fraction",
    "Number of Components",
    "Largest Component Area",
    "Largest Component Area Fraction",
    "Total Perimeter",
    "Centroid X",
    "Centroid Y",
    "Major Axis Length",
    "Minor Axis Length",
    "Aspect Ratio",
    "Orientation Angle",
    "Solidity",
    "Compactness",
    "Boundary Roughness",
    "Whole Mask Solidity",
    "Mean Boundary Displacement",
    "Median Boundary Displacement",
    "Max Boundary Displacement",
    "Mean Signed Boundary Displacement",
    "Touches Border",
    "Quality Flags",
]

COMPONENT_HEADERS = [
    "Frame",
    "Component Label",
    "Area",
    "Centroid X",
    "Centroid Y",
    "BBox Min Row",
    "BBox Min Col",
    "BBox Max Row",
    "BBox Max Col",
    "Major Axis Length",
    "Minor Axis Length",
    "Orientation Angle",
    "Solidity",
]

COMPONENT_TRAJECTORY_HEADERS = [
    "Frame",
    "Persistent Label",
    "Centroid X",
    "Centroid Y",
    "Area",
    "Major Axis Length",
    "Minor Axis Length",
    "Aspect Ratio",
    "Orientation Angle",
    "Solidity",
]

MASKED_FLOW_HEADERS = [
    "Frame Start",
    "Frame End",
    "Masked Area Fraction",
    "Masked Flow Cell Count",
    "Unmasked Mean Speed",
    "Masked Mean Speed",
    "Masked Speed Ratio",
    "Unmasked Mean VX",
    "Unmasked Mean VY",
    "Masked Mean VX",
    "Masked Mean VY",
    "Unmasked Mean Direction",
    "Masked Mean Direction",
    "Unmasked Direction Coherence",
    "Masked Direction Coherence",
    "Quality Flags",
]

MASKED_FLOW_COMPONENT_HEADERS = [
    "Frame Start",
    "Frame End",
    "Component Label",
    "Component Area",
    "Component Centroid X",
    "Component Centroid Y",
    "Component Mean Speed",
    "Component Mean Direction",
    "Component Direction Coherence",
    "Quality Flags",
]


def _finite_mean(values: np.ndarray) -> float:
    if len(values) == 0 or np.isnan(values).all():
        return np.nan
    return float(np.nanmean(values))


def _finite_max(values: np.ndarray) -> float:
    if len(values) == 0 or np.isnan(values).all():
        return np.nan
    return float(np.nanmax(values))


def _safe_ratio(numerator: float, denominator: float) -> float:
    if denominator == 0 or np.isnan(denominator):
        return np.nan
    return float(numerator / denominator)


def _evaluation_count(num_values: int, fraction: float) -> int:
    return max(1, int(np.ceil(num_values * fraction)))


def _normalize_for_threshold(frame: np.ndarray) -> np.ndarray:
    frame = frame.astype(float)
    min_val = np.nanmin(frame)
    max_val = np.nanmax(frame)
    if max_val == min_val:
        return np.zeros_like(frame, dtype=float)
    return (frame - min_val) / (max_val - min_val)


def _compute_threshold(frame: np.ndarray, seg_config: SegmentationConfig) -> float:
    method = seg_config.threshold_method.lower()
    if method == "otsu":
        threshold = filters.threshold_otsu(frame)
    elif method == "mean":
        threshold = float(np.nanmean(frame))
    elif method == "percentile":
        threshold = float(np.nanpercentile(frame, 50))
    else:
        raise ValueError(f"Unsupported segmentation threshold method: {seg_config.threshold_method}")
    return threshold * (1 + seg_config.threshold_offset)


def segment_frame(frame: np.ndarray, seg_config: SegmentationConfig) -> Tuple[np.ndarray, float]:
    """Create a cleaned material mask for one microscopy frame."""
    working = _normalize_for_threshold(frame)
    if seg_config.smoothing_sigma > 0:
        working = ndimage.gaussian_filter(working, sigma=seg_config.smoothing_sigma)

    threshold = _compute_threshold(working, seg_config)
    mask = working >= threshold
    if seg_config.invert_segmentation:
        mask = ~mask

    if seg_config.opening_size > 0:
        footprint = morphology.disk(seg_config.opening_size)
        mask = morphology.binary_opening(mask, footprint)
    if seg_config.closing_size > 0:
        footprint = morphology.disk(seg_config.closing_size)
        mask = morphology.binary_closing(mask, footprint)
    if seg_config.minimum_object_size > 1:
        mask = morphology.remove_small_objects(mask, seg_config.minimum_object_size, connectivity=2)
    if seg_config.hole_filling_size > 1:
        mask = morphology.remove_small_holes(mask, seg_config.hole_filling_size, connectivity=2)

    return mask.astype(bool), threshold


def _touches_border(mask: np.ndarray) -> int:
    if mask.size == 0:
        return 0
    return int(
        np.any(mask[0, :])
        or np.any(mask[-1, :])
        or np.any(mask[:, 0])
        or np.any(mask[:, -1])
    )


def _boundary_mask(mask: np.ndarray) -> np.ndarray:
    if mask.size == 0 or not np.any(mask):
        return np.zeros_like(mask, dtype=bool)
    eroded = morphology.binary_erosion(mask, morphology.square(3))
    return mask & ~eroded


def _boundary_displacement_metrics(
    mask: np.ndarray,
    reference_mask: np.ndarray,
    um_pixel_ratio: float,
) -> tuple[float, float, float, float]:
    """Measure current boundary distance from the initial reference boundary."""
    current_boundary = _boundary_mask(mask)
    reference_boundary = _boundary_mask(reference_mask)
    if not np.any(current_boundary) or not np.any(reference_boundary):
        return np.nan, np.nan, np.nan, np.nan

    distance_to_reference = ndimage.distance_transform_edt(~reference_boundary)
    distances = distance_to_reference[current_boundary] * um_pixel_ratio

    # Negative values indicate boundary pixels that lie inside the initial material mask
    # and positive values indicate boundary pixels outside it. This is a coarse
    # contraction/expansion sign, not a full normal-direction displacement field.
    signed_direction = np.where(reference_mask[current_boundary], -1, 1)
    signed_distances = distances * signed_direction

    return (
        float(np.nanmean(distances)),
        float(np.nanmedian(distances)),
        float(np.nanmax(distances)),
        float(np.nanmean(signed_distances)),
    )


def _convex_hull_perimeter(component_image: np.ndarray) -> float:
    if component_image.size == 0 or not np.any(component_image):
        return np.nan
    convex_image = morphology.convex_hull_image(component_image)
    perimeter = measure.perimeter(convex_image)
    return float(perimeter) if perimeter > 0 else np.nan


def _boundary_roughness(component_image: np.ndarray, perimeter: float) -> float:
    convex_perimeter = _convex_hull_perimeter(component_image)
    return _safe_ratio(perimeter, convex_perimeter)


def _whole_mask_solidity(mask: np.ndarray) -> float:
    if mask.size == 0 or not np.any(mask):
        return np.nan
    convex_image = morphology.convex_hull_image(mask)
    convex_area = float(np.sum(convex_image))
    return _safe_ratio(float(np.sum(mask)), convex_area)


def _quality_flags(
    area_fraction: float,
    num_components: int,
    touches_border: int,
    threshold: float,
    frame: np.ndarray,
    seg_config: SegmentationConfig,
) -> str:
    flags = []
    if np.isnan(area_fraction):
        flags.append("segmentation_failed")
    if area_fraction <= 0:
        flags.append("empty_mask")
    if area_fraction >= 1:
        flags.append("full_frame_mask")
    if area_fraction < seg_config.min_area_fraction:
        flags.append("mask_area_too_small")
    if area_fraction > seg_config.max_area_fraction:
        flags.append("mask_area_too_large")
    if touches_border:
        flags.append("object_touches_border")
    if num_components > seg_config.max_components:
        flags.append("too_many_fragments")
    if np.nanstd(frame) < 1e-8 or threshold <= 0 or threshold >= 1:
        flags.append("low_contrast_or_unstable_threshold")
    return ";".join(flags) if flags else "0"


def _frame_metrics(
    frame_idx: int,
    frame: np.ndarray,
    mask: np.ndarray,
    threshold: float,
    seg_config: SegmentationConfig,
    reference_mask: np.ndarray,
    um_pixel_ratio: float,
) -> Tuple[list, list[list]]:
    labeled = measure.label(mask, connectivity=2)
    props = list(measure.regionprops(labeled))
    image_area = mask.shape[0] * mask.shape[1]
    total_area = float(mask.sum())
    area_fraction = _safe_ratio(total_area, image_area)
    num_components = len(props)
    touches_border = _touches_border(mask)
    mean_boundary_displacement, median_boundary_displacement, max_boundary_displacement, mean_signed_boundary_displacement = _boundary_displacement_metrics(
        mask,
        reference_mask,
        um_pixel_ratio,
    )

    largest_area = np.nan
    largest_area_fraction = np.nan
    centroid_x = np.nan
    centroid_y = np.nan
    major_axis = np.nan
    minor_axis = np.nan
    aspect_ratio = np.nan
    orientation = np.nan
    solidity = np.nan
    compactness = np.nan
    boundary_roughness = np.nan
    whole_mask_solidity = _whole_mask_solidity(mask)
    total_perimeter = np.nan
    component_rows = []

    if props:
        props_sorted = sorted(props, key=lambda prop: prop.area, reverse=True)
        largest = props_sorted[0]
        largest_area = float(largest.area)
        largest_area_fraction = _safe_ratio(largest_area, image_area)
        centroid_y, centroid_x = largest.centroid
        major_axis = float(largest.major_axis_length)
        minor_axis = float(largest.minor_axis_length)
        aspect_ratio = _safe_ratio(major_axis, minor_axis)
        orientation = float(largest.orientation)
        solidity = float(largest.solidity)
        total_perimeter = float(np.nansum([prop.perimeter for prop in props]))
        boundary_roughness = _boundary_roughness(largest.image, float(largest.perimeter))
        if largest.perimeter > 0:
            compactness = float(4 * np.pi * largest.area / (largest.perimeter ** 2))

        for prop in props_sorted:
            cy, cx = prop.centroid
            min_row, min_col, max_row, max_col = prop.bbox
            component_rows.append([
                frame_idx,
                prop.label,
                float(prop.area),
                float(cx),
                float(cy),
                min_row,
                min_col,
                max_row,
                max_col,
                float(prop.major_axis_length),
                float(prop.minor_axis_length),
                float(prop.orientation),
                float(prop.solidity),
            ])

    flags = _quality_flags(area_fraction, num_components, touches_border, threshold, frame, seg_config)
    row = [
        frame_idx,
        threshold,
        total_area,
        area_fraction,
        num_components,
        largest_area,
        largest_area_fraction,
        total_perimeter,
        centroid_x,
        centroid_y,
        major_axis,
        minor_axis,
        aspect_ratio,
        orientation,
        solidity,
        compactness,
        boundary_roughness,
        whole_mask_solidity,
        mean_boundary_displacement,
        median_boundary_displacement,
        max_boundary_displacement,
        mean_signed_boundary_displacement,
        touches_border,
        flags,
    ]
    return row, component_rows


def _write_mask_rds(csvwriter, frame_idx: int, mask: np.ndarray) -> None:
    csvwriter.writerow([f"Frame {frame_idx}"])
    csvwriter.writerows(mask.astype(int))
    csvwriter.writerow([])


def _label_color_image(labeled: np.ndarray) -> np.ndarray:
    """Create a deterministic pseudo-color image for labeled components."""
    color_image = np.zeros(labeled.shape + (3,), dtype=float)
    labels = np.unique(labeled)
    labels = labels[labels != 0]
    for label_value in labels:
        rng = np.random.default_rng(int(label_value))
        color_image[labeled == label_value] = rng.uniform(0.20, 0.95, size=3)
    return color_image


def _draw_component_labels(ax, labeled: np.ndarray, max_labels: int | None = None) -> None:
    props = sorted(measure.regionprops(labeled), key=lambda prop: prop.area, reverse=True)
    if max_labels is not None:
        props = props[:max_labels]
    for prop in props:
        cy, cx = prop.centroid
        ax.text(
            cx,
            cy,
            str(prop.label),
            color="white",
            fontsize=7,
            ha="center",
            va="center",
            bbox={
                "boxstyle": "round,pad=0.18",
                "facecolor": "black",
                "edgecolor": "none",
                "alpha": 0.65,
            },
        )


def _save_overlay(frame: np.ndarray, mask: np.ndarray, frame_idx: int, output_dir: str) -> None:
    contours = measure.find_contours(mask.astype(float), 0.5)
    fig, ax = plt.subplots(figsize=(7, 7))
    ax.imshow(frame, cmap="gray")
    for contour in contours:
        ax.plot(contour[:, 1], contour[:, 0], color="cyan", linewidth=1.2)
    ax.axis("off")
    fig.savefig(os.path.join(output_dir, f"Segmentation Frame {frame_idx} Overlay.png"), bbox_inches="tight", pad_inches=0)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 7))
    ax.imshow(mask, cmap="gray", interpolation="nearest")
    ax.axis("off")
    fig.savefig(os.path.join(output_dir, f"Segmentation Frame {frame_idx} Mask.png"), bbox_inches="tight", pad_inches=0)
    plt.close(fig)


def _save_labeled_components(frame: np.ndarray, mask: np.ndarray, frame_idx: int, output_dir: str) -> None:
    labeled = measure.label(mask, connectivity=2)
    label_image = _label_color_image(labeled)
    contours = measure.find_contours(mask.astype(float), 0.5)

    fig, axs = plt.subplots(1, 3, figsize=(15, 5))
    axs[0].imshow(frame, cmap="gray")
    axs[0].set_title(f"Original Frame {frame_idx}")

    axs[1].imshow(frame, cmap="gray")
    for contour in contours:
        axs[1].plot(contour[:, 1], contour[:, 0], color="cyan", linewidth=1.1)
    _draw_component_labels(axs[1], labeled)
    axs[1].set_title("Boundary Overlay + Component Labels")

    axs[2].imshow(label_image, interpolation="nearest")
    _draw_component_labels(axs[2], labeled)
    axs[2].set_title("Labeled Components")

    for ax in axs:
        ax.axis("off")

    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"Segmentation Frame {frame_idx} Labeled Components.png"), bbox_inches="tight")
    plt.close(fig)


def _save_frame_contact_sheet(examples: list[tuple[int, np.ndarray, np.ndarray]], output_dir: str) -> None:
    if not examples:
        return

    fig, axs = plt.subplots(len(examples), 3, figsize=(15, 5 * len(examples)))
    if len(examples) == 1:
        axs = np.expand_dims(axs, axis=0)

    for row_idx, (frame_idx, frame, mask) in enumerate(examples):
        labeled = measure.label(mask, connectivity=2)
        label_image = _label_color_image(labeled)
        contours = measure.find_contours(mask.astype(float), 0.5)

        axs[row_idx, 0].imshow(frame, cmap="gray")
        axs[row_idx, 0].set_title(f"Original Frame {frame_idx}")

        axs[row_idx, 1].imshow(frame, cmap="gray")
        for contour in contours:
            axs[row_idx, 1].plot(contour[:, 1], contour[:, 0], color="cyan", linewidth=1.1)
        _draw_component_labels(axs[row_idx, 1], labeled)
        axs[row_idx, 1].set_title("Segmentation Boundary + Labels")

        axs[row_idx, 2].imshow(label_image, interpolation="nearest")
        _draw_component_labels(axs[row_idx, 2], labeled)
        axs[row_idx, 2].set_title("Component Label Mask")

        for col_idx in range(3):
            axs[row_idx, col_idx].axis("off")

    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, "Segmentation First Middle Last Components.png"), bbox_inches="tight")
    plt.close(fig)


def _assign_persistent_labels(
    raw_labeled: np.ndarray,
    previous_labeled: np.ndarray | None,
    previous_centroids: dict[int, tuple[float, float]],
    next_label: int,
) -> tuple[np.ndarray, dict[int, tuple[float, float]], int]:
    persistent_labeled = np.zeros_like(raw_labeled, dtype=int)
    current_centroids = {}
    used_labels = set()
    max_centroid_distance = 0.05 * np.sqrt(raw_labeled.shape[0] ** 2 + raw_labeled.shape[1] ** 2)

    for prop in sorted(measure.regionprops(raw_labeled), key=lambda region: region.area, reverse=True):
        component_mask = raw_labeled == prop.label
        assigned_label = None

        if previous_labeled is not None:
            overlap_labels, overlap_counts = np.unique(previous_labeled[component_mask], return_counts=True)
            overlap_pairs = [
                (int(label_value), int(count))
                for label_value, count in zip(overlap_labels, overlap_counts)
                if label_value != 0 and int(label_value) not in used_labels
            ]
            if overlap_pairs:
                assigned_label = max(overlap_pairs, key=lambda pair: pair[1])[0]

        if assigned_label is None and previous_centroids:
            cy, cx = prop.centroid
            candidates = []
            for label_value, (prev_cy, prev_cx) in previous_centroids.items():
                if label_value in used_labels:
                    continue
                distance = np.sqrt((cy - prev_cy) ** 2 + (cx - prev_cx) ** 2)
                if distance <= max_centroid_distance:
                    candidates.append((label_value, distance))
            if candidates:
                assigned_label = min(candidates, key=lambda pair: pair[1])[0]

        if assigned_label is None:
            assigned_label = next_label
            next_label += 1

        persistent_labeled[component_mask] = assigned_label
        current_centroids[assigned_label] = prop.centroid
        used_labels.add(assigned_label)

    return persistent_labeled, current_centroids, next_label


def _render_labeled_video_frame(frame: np.ndarray, persistent_labeled: np.ndarray, frame_idx: int) -> np.ndarray:
    mask = persistent_labeled > 0
    label_image = _label_color_image(persistent_labeled)
    contours = measure.find_contours(mask.astype(float), 0.5)

    fig, axs = plt.subplots(1, 3, figsize=(15, 5), dpi=120)
    axs[0].imshow(frame, cmap="gray")
    axs[0].set_title(f"Original Frame {frame_idx}")

    axs[1].imshow(frame, cmap="gray")
    for contour in contours:
        axs[1].plot(contour[:, 1], contour[:, 0], color="cyan", linewidth=1.0)
    _draw_component_labels(axs[1], persistent_labeled)
    axs[1].set_title("Segmentation Overlay + Persistent Labels")

    axs[2].imshow(label_image, interpolation="nearest")
    _draw_component_labels(axs[2], persistent_labeled)
    axs[2].set_title("Tracked Component Label Mask")

    for ax in axs:
        ax.axis("off")

    fig.tight_layout()
    fig.canvas.draw()
    image = np.asarray(fig.canvas.buffer_rgba())[..., :3].copy()
    plt.close(fig)
    return image


def _save_labeled_segmentation_video(video: np.ndarray, seg_config: SegmentationConfig, output_dir: str) -> None:
    try:
        import cv2 as cv
    except ImportError:
        vprint("OpenCV is unavailable; labeled segmentation video was not saved.")
        return

    frame_step = max(1, int(seg_config.labeled_video_frame_step))
    video_indices, _ = find_analysis_frames(video, frame_step)
    fps = max(0.1, float(seg_config.labeled_video_fps))
    output_path = os.path.join(output_dir, "Segmentation Labeled Components.mp4")

    writer = None
    previous_labeled = None
    previous_centroids = {}
    next_label = 1

    try:
        for frame_idx in video_indices:
            frame = video[frame_idx]
            mask, _ = segment_frame(frame, seg_config)
            raw_labeled = measure.label(mask, connectivity=2)
            persistent_labeled, previous_centroids, next_label = _assign_persistent_labels(
                raw_labeled,
                previous_labeled,
                previous_centroids,
                next_label,
            )
            previous_labeled = persistent_labeled

            rendered = _render_labeled_video_frame(frame, persistent_labeled, frame_idx)
            height, width = rendered.shape[:2]

            if writer is None:
                fourcc = cv.VideoWriter_fourcc(*"mp4v")
                writer = cv.VideoWriter(output_path, fourcc, fps, (width, height))
                if not writer.isOpened():
                    vprint("Unable to open video writer; labeled segmentation video was not saved.")
                    return

            writer.write(cv.cvtColor(rendered, cv.COLOR_RGB2BGR))
    finally:
        if writer is not None:
            writer.release()


def _component_rows_from_persistent_labels(frame_idx: int, persistent_labeled: np.ndarray) -> list[list]:
    rows = []
    for prop in measure.regionprops(persistent_labeled):
        cy, cx = prop.centroid
        aspect_ratio = _safe_ratio(float(prop.major_axis_length), float(prop.minor_axis_length))
        rows.append([
            frame_idx,
            prop.label,
            float(cx),
            float(cy),
            float(prop.area),
            float(prop.major_axis_length),
            float(prop.minor_axis_length),
            aspect_ratio,
            float(prop.orientation),
            float(prop.solidity),
        ])
    return rows


def _save_component_trajectory_plot(rows: list[list], output_dir: str) -> None:
    if not rows:
        return

    data_by_label = {}
    for row in rows:
        frame_idx, label_value, cx, cy = row[:4]
        data_by_label.setdefault(int(label_value), []).append((float(frame_idx), float(cx), float(cy)))

    fig, ax = plt.subplots(figsize=(8, 8))
    all_frames = np.array([row[0] for row in rows], dtype=float)
    frame_min = float(np.nanmin(all_frames))
    frame_max = float(np.nanmax(all_frames))
    norm = plt.Normalize(frame_min, frame_max if frame_max > frame_min else frame_min + 1)
    cmap = plt.get_cmap("viridis")

    for label_value, points in data_by_label.items():
        points = sorted(points, key=lambda item: item[0])
        frames = np.array([point[0] for point in points])
        xs = np.array([point[1] for point in points])
        ys = np.array([point[2] for point in points])
        if len(points) > 1:
            ax.plot(xs, ys, color="lightgray", linewidth=1.0, alpha=0.8, zorder=1)
        ax.scatter(xs, ys, c=frames, cmap=cmap, norm=norm, s=28, zorder=2)
        ax.text(xs[-1], ys[-1], str(label_value), fontsize=7, color="black")

    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax)
    cbar.set_label("Frame")
    ax.set_title("Per-Component Centroid Trajectories")
    ax.set_xlabel("Centroid X (pixels)")
    ax.set_ylabel("Centroid Y (pixels)")
    ax.set_aspect("equal", adjustable="box")
    ax.invert_yaxis()
    fig.savefig(os.path.join(output_dir, "Segmentation Component Trajectories.png"), bbox_inches="tight")
    plt.close(fig)


def _save_component_trajectories(video: np.ndarray, seg_config: SegmentationConfig, output_dir: str) -> None:
    frame_step = max(1, int(seg_config.component_trajectory_frame_step))
    frame_indices, _ = find_analysis_frames(video, frame_step)
    output_path = os.path.join(output_dir, "SegmentationComponentTrajectories.csv")

    previous_labeled = None
    previous_centroids = {}
    next_label = 1
    trajectory_rows = []

    for frame_idx in frame_indices:
        frame = video[frame_idx]
        mask, _ = segment_frame(frame, seg_config)
        raw_labeled = measure.label(mask, connectivity=2)
        persistent_labeled, previous_centroids, next_label = _assign_persistent_labels(
            raw_labeled,
            previous_labeled,
            previous_centroids,
            next_label,
        )
        previous_labeled = persistent_labeled
        trajectory_rows.extend(_component_rows_from_persistent_labels(frame_idx, persistent_labeled))

    with open(output_path, "w", newline="", encoding="utf-8") as trajectory_file:
        writer = csv.writer(trajectory_file)
        writer.writerow(COMPONENT_TRAJECTORY_HEADERS)
        writer.writerows(trajectory_rows)

    _save_component_trajectory_plot(trajectory_rows, output_dir)


def _save_timeseries_plot(xvalues: np.ndarray, yvalues: np.ndarray, xlabel: str, ylabel: str, output_dir: str, filename: str) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(7, 7))
    ax.plot(xvalues, yvalues, marker="o", linewidth=1.5)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    fig.savefig(os.path.join(output_dir, filename), bbox_inches="tight")
    return fig


def _save_centroid_plot(frames: np.ndarray, cx: np.ndarray, cy: np.ndarray, output_dir: str) -> None:
    fig, ax = plt.subplots(figsize=(7, 7))
    valid = ~(np.isnan(cx) | np.isnan(cy))
    if np.any(valid):
        ax.plot(cx[valid], cy[valid], color="lightgray", linewidth=1.5, zorder=1)
        scatter = ax.scatter(cx[valid], cy[valid], c=frames[valid], cmap="viridis", s=45, zorder=2)
        ax.scatter(cx[valid][0], cy[valid][0], c="green", label="Start")
        ax.scatter(cx[valid][-1], cy[valid][-1], c="purple", label="End")
        cbar = fig.colorbar(scatter, ax=ax)
        cbar.set_label("Frame")
        ax.legend()
    ax.set_xlabel("Centroid X (pixels)")
    ax.set_ylabel("Centroid Y (pixels)")
    ax.set_aspect("equal", adjustable="box")
    ax.invert_yaxis()
    fig.savefig(os.path.join(output_dir, "Segmentation Centroid Trajectory.png"), bbox_inches="tight")
    plt.close(fig)


def _save_showcase_plot(
    frames: np.ndarray,
    area_fraction: np.ndarray,
    num_components: np.ndarray,
    largest_component_fraction: np.ndarray,
    aspect_ratio: np.ndarray,
    centroid_x: np.ndarray,
    centroid_y: np.ndarray,
    flags: list[str],
    output_dir: str,
) -> None:
    """Save a compact multi-panel diagnostic for segmentation results."""
    fig, axs = plt.subplots(2, 3, figsize=(15, 8))

    axs[0, 0].plot(frames, area_fraction, marker="o", linewidth=1.5)
    axs[0, 0].set_title("Material Area Fraction")
    axs[0, 0].set_xlabel("Frame")
    axs[0, 0].set_ylabel("Area Fraction")

    axs[0, 1].plot(frames, num_components, marker="o", linewidth=1.5)
    axs[0, 1].set_title("Connected Components")
    axs[0, 1].set_xlabel("Frame")
    axs[0, 1].set_ylabel("Count")

    axs[0, 2].plot(frames, largest_component_fraction, marker="o", linewidth=1.5)
    axs[0, 2].set_title("Largest Component Fraction")
    axs[0, 2].set_xlabel("Frame")
    axs[0, 2].set_ylabel("Area Fraction")

    axs[1, 0].plot(frames, aspect_ratio, marker="o", linewidth=1.5)
    axs[1, 0].set_title("Largest Component Aspect Ratio")
    axs[1, 0].set_xlabel("Frame")
    axs[1, 0].set_ylabel("Aspect Ratio")

    valid_centroids = ~(np.isnan(centroid_x) | np.isnan(centroid_y))
    if np.any(valid_centroids):
        axs[1, 1].plot(centroid_x[valid_centroids], centroid_y[valid_centroids], marker="o", linewidth=1.5)
        axs[1, 1].scatter(centroid_x[valid_centroids][0], centroid_y[valid_centroids][0], c="green", label="Start")
        axs[1, 1].scatter(centroid_x[valid_centroids][-1], centroid_y[valid_centroids][-1], c="purple", label="End")
        axs[1, 1].legend()
    axs[1, 1].set_title("Centroid Trajectory")
    axs[1, 1].set_xlabel("Centroid X (pixels)")
    axs[1, 1].set_ylabel("Centroid Y (pixels)")
    axs[1, 1].invert_yaxis()

    flag_values = np.array([0 if flag == "0" else 1 for flag in flags], dtype=float).reshape(1, -1)
    axs[1, 2].imshow(flag_values, aspect="auto", cmap="gray_r", interpolation="nearest")
    axs[1, 2].set_title("Quality Flag Timeline")
    axs[1, 2].set_xlabel("Analyzed Frame")
    axs[1, 2].set_yticks([])
    axs[1, 2].set_xticks(range(len(frames)))
    axs[1, 2].set_xticklabels([str(int(frame)) for frame in frames], rotation=45, ha="right")

    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, "Segmentation Showcase.png"), bbox_inches="tight")
    plt.close(fig)


def _compute_reduced_flow(
    video: np.ndarray,
    start: int,
    stop: int,
    flow_config: OpticalFlowConfig,
    in_config: ReaderConfig,
) -> tuple[np.ndarray, np.ndarray]:
    try:
        import cv2 as cv
    except ImportError as exc:
        raise ImportError("OpenCV is required for masked flow metrics.") from exc

    flow = cv.calcOpticalFlowFarneback(
        video[start],
        video[stop],
        None,
        0.5,
        3,
        flow_config.win_size,
        3,
        5,
        1.2,
        0,
    )
    flow_reduced = groupAvg(flow, flow_config.downsample)
    scale = (1 / in_config.exposure_time) * (1 / (stop - start)) * in_config.um_pixel_ratio
    down_u = np.flipud(flow_reduced[:, :, 0]) * scale
    down_v = -1 * np.flipud(flow_reduced[:, :, 1]) * scale
    return down_u, down_v


def _downsample_mask_for_flow(mask: np.ndarray, downsample: int, target_shape: tuple[int, int]) -> np.ndarray:
    coverage = groupAvg(mask.astype(float), downsample)
    reduced_mask = np.flipud(coverage) >= 0.5
    rows = min(reduced_mask.shape[0], target_shape[0])
    cols = min(reduced_mask.shape[1], target_shape[1])
    aligned = np.zeros(target_shape, dtype=bool)
    aligned[:rows, :cols] = reduced_mask[:rows, :cols]
    return aligned


def _flow_summary(down_u: np.ndarray, down_v: np.ndarray, mask: np.ndarray | None = None) -> dict:
    if mask is None:
        valid = np.ones(down_u.shape, dtype=bool)
    else:
        valid = mask.astype(bool)
    valid &= ~(np.isnan(down_u) | np.isnan(down_v))

    if not np.any(valid):
        return {
            "count": 0,
            "mean_speed": np.nan,
            "mean_vx": np.nan,
            "mean_vy": np.nan,
            "mean_direction": np.nan,
            "direction_coherence": np.nan,
        }

    vx = down_u[valid]
    vy = down_v[valid]
    speed = np.sqrt(vx ** 2 + vy ** 2)
    mean_speed = float(np.nanmean(speed))
    mean_vx = float(np.nanmean(vx))
    mean_vy = float(np.nanmean(vy))
    mean_direction = float(np.arctan2(mean_vy, mean_vx))
    direction_coherence = _safe_ratio(float(np.sqrt(mean_vx ** 2 + mean_vy ** 2)), mean_speed)
    return {
        "count": int(np.count_nonzero(valid)),
        "mean_speed": mean_speed,
        "mean_vx": mean_vx,
        "mean_vy": mean_vy,
        "mean_direction": mean_direction,
        "direction_coherence": direction_coherence,
    }


def _masked_flow_flags(mask_area_fraction: float, masked_summary: dict) -> str:
    flags = []
    if mask_area_fraction <= 0:
        flags.append("empty_mask")
    if mask_area_fraction < 0.001:
        flags.append("small_masked_area")
    if masked_summary["count"] == 0:
        flags.append("no_masked_flow_cells")
    if np.isnan(masked_summary["mean_speed"]):
        flags.append("no_valid_masked_flow")
    return ";".join(flags) if flags else "0"


def _masked_flow_metric_row(
    start: int,
    stop: int,
    mask: np.ndarray,
    reduced_mask: np.ndarray,
    down_u: np.ndarray,
    down_v: np.ndarray,
) -> tuple[list, dict, dict]:
    unmasked_summary = _flow_summary(down_u, down_v)
    masked_summary = _flow_summary(down_u, down_v, reduced_mask)
    mask_area_fraction = _safe_ratio(float(np.sum(mask)), float(mask.size))
    masked_speed_ratio = _safe_ratio(masked_summary["mean_speed"], unmasked_summary["mean_speed"])
    flags = _masked_flow_flags(mask_area_fraction, masked_summary)
    row = [
        start,
        stop,
        mask_area_fraction,
        masked_summary["count"],
        unmasked_summary["mean_speed"],
        masked_summary["mean_speed"],
        masked_speed_ratio,
        unmasked_summary["mean_vx"],
        unmasked_summary["mean_vy"],
        masked_summary["mean_vx"],
        masked_summary["mean_vy"],
        unmasked_summary["mean_direction"],
        masked_summary["mean_direction"],
        unmasked_summary["direction_coherence"],
        masked_summary["direction_coherence"],
        flags,
    ]
    return row, unmasked_summary, masked_summary


def _masked_flow_component_rows(
    start: int,
    stop: int,
    mask: np.ndarray,
    down_u: np.ndarray,
    down_v: np.ndarray,
    downsample: int,
) -> list[list]:
    rows = []
    labeled = measure.label(mask, connectivity=2)
    for prop in measure.regionprops(labeled):
        component_mask = labeled == prop.label
        reduced_component_mask = _downsample_mask_for_flow(component_mask, downsample, down_u.shape)
        summary = _flow_summary(down_u, down_v, reduced_component_mask)
        flags = "0" if summary["count"] > 0 else "no_component_flow_cells"
        cy, cx = prop.centroid
        rows.append([
            start,
            stop,
            int(prop.label),
            float(prop.area),
            float(cx),
            float(cy),
            summary["mean_speed"],
            summary["mean_direction"],
            summary["direction_coherence"],
            flags,
        ])
    return rows


def _save_masked_flow_comparison(
    frame: np.ndarray,
    mask: np.ndarray,
    reduced_mask: np.ndarray,
    down_u: np.ndarray,
    down_v: np.ndarray,
    start: int,
    stop: int,
    unmasked_summary: dict,
    masked_summary: dict,
    output_dir: str,
) -> None:
    speed = np.sqrt(down_u ** 2 + down_v ** 2)
    yy, xx = np.mgrid[0:down_u.shape[0], 0:down_u.shape[1]]
    contours = measure.find_contours(mask.astype(float), 0.5)

    fig, axs = plt.subplots(1, 4, figsize=(20, 5))
    axs[0].imshow(frame, cmap="gray")
    for contour in contours:
        axs[0].plot(contour[:, 1], contour[:, 0], color="cyan", linewidth=1.0)
    axs[0].set_title(f"Frame {start} Segmentation")
    axs[0].axis("off")

    q1 = axs[1].quiver(xx, yy, down_u, down_v, speed, cmap="plasma")
    axs[1].set_title("Full-FOV Flow")
    axs[1].set_aspect("equal", adjustable="box")
    axs[1].invert_yaxis()
    fig.colorbar(q1, ax=axs[1], fraction=0.046, pad=0.04)

    if np.any(reduced_mask):
        q2 = axs[2].quiver(
            xx[reduced_mask],
            yy[reduced_mask],
            down_u[reduced_mask],
            down_v[reduced_mask],
            speed[reduced_mask],
            cmap="plasma",
        )
        fig.colorbar(q2, ax=axs[2], fraction=0.046, pad=0.04)
    else:
        axs[2].text(0.5, 0.5, "No masked flow cells", transform=axs[2].transAxes, ha="center", va="center")
    axs[2].set_title("Masked Flow")
    axs[2].set_aspect("equal", adjustable="box")
    axs[2].invert_yaxis()

    labels = ["Unmasked", "Masked"]
    values = [unmasked_summary["mean_speed"], masked_summary["mean_speed"]]
    axs[3].bar(labels, values, color=["#6c757d", "#2a9d8f"])
    axs[3].set_ylabel("Mean Speed")
    axs[3].set_title("Mean Speed Comparison")
    ratio = _safe_ratio(masked_summary["mean_speed"], unmasked_summary["mean_speed"])
    axs[3].text(
        0.5,
        0.92,
        f"Speed ratio: {ratio:.3g}\nMasked coherence: {masked_summary['direction_coherence']:.3g}",
        transform=axs[3].transAxes,
        ha="center",
        va="top",
    )

    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"Masked Flow Comparison Frame {start} to {stop}.png"), bbox_inches="tight")
    plt.close(fig)


def _save_masked_flow_metrics(
    video: np.ndarray,
    seg_config: SegmentationConfig,
    flow_config: OpticalFlowConfig,
    in_config: ReaderConfig,
    output_dir: str,
) -> None:
    vprint("Beginning Masked Dynamic Behavior Analysis")
    frame_indices, _ = find_analysis_frames(video, flow_config.frame_step)
    if len(frame_indices) < 2:
        return

    flow_pairs = [(frame_indices[i], frame_indices[i + 1]) for i in range(len(frame_indices) - 1)]
    save_pairs = set()
    if seg_config.save_masked_flow_visualizations:
        save_pairs = {
            flow_pairs[0],
            flow_pairs[int((len(flow_pairs) - 1) / 2)],
            flow_pairs[-1],
        }

    metrics_path = os.path.join(output_dir, "MaskedFlowMetrics.csv")
    components_path = os.path.join(output_dir, "MaskedFlowComponents.csv")
    with open(metrics_path, "w", newline="", encoding="utf-8") as metrics_file, open(
        components_path,
        "w",
        newline="",
        encoding="utf-8",
    ) as components_file:
        metrics_writer = csv.writer(metrics_file)
        components_writer = csv.writer(components_file)
        metrics_writer.writerow(MASKED_FLOW_HEADERS)
        components_writer.writerow(MASKED_FLOW_COMPONENT_HEADERS)

        for start, stop in flow_pairs:
            frame = video[start]
            mask, _ = segment_frame(frame, seg_config)
            down_u, down_v = _compute_reduced_flow(video, start, stop, flow_config, in_config)
            reduced_mask = _downsample_mask_for_flow(mask, flow_config.downsample, down_u.shape)
            row, unmasked_summary, masked_summary = _masked_flow_metric_row(
                start,
                stop,
                mask,
                reduced_mask,
                down_u,
                down_v,
            )
            metrics_writer.writerow(row)
            components_writer.writerows(
                _masked_flow_component_rows(start, stop, mask, down_u, down_v, flow_config.downsample)
            )

            if (start, stop) in save_pairs:
                _save_masked_flow_comparison(
                    frame,
                    mask,
                    reduced_mask,
                    down_u,
                    down_v,
                    start,
                    stop,
                    unmasked_summary,
                    masked_summary,
                    output_dir,
                )


def _summarize(rows: list[list], seg_config: SegmentationConfig, in_config: ReaderConfig) -> SegmentationResults:
    if not rows:
        return SegmentationResults(segmentation_quality_flag=1)

    data = np.array([row[:-1] for row in rows], dtype=float)
    centroid_x = data[:, 8]
    centroid_y = data[:, 9]
    solidity = data[:, 17]
    boundary_roughness = data[:, 16]
    mean_boundary_displacement = data[:, 18]
    max_boundary_displacement = data[:, 20]
    mean_signed_boundary_displacement = data[:, 21]

    eval_count = _evaluation_count(len(rows), seg_config.percentage_frames_evaluated)
    initial_roughness = _finite_mean(boundary_roughness[:eval_count])
    final_roughness = _finite_mean(boundary_roughness[-eval_count:])
    initial_solidity = _finite_mean(solidity[:eval_count])
    final_solidity = _finite_mean(solidity[-eval_count:])

    valid_centroids = ~(np.isnan(centroid_x) | np.isnan(centroid_y))
    centroid_displacement = np.nan
    if np.any(valid_centroids):
        start = np.array([centroid_x[valid_centroids][0], centroid_y[valid_centroids][0]])
        end = np.array([centroid_x[valid_centroids][-1], centroid_y[valid_centroids][-1]])
        centroid_displacement = float(np.linalg.norm(end - start) * in_config.um_pixel_ratio)

    quality_flag = int(any(row[-1] != "0" for row in rows))
    return SegmentationResults(
        centroid_displacement=centroid_displacement,
        final_boundary_displacement=_finite_mean(mean_boundary_displacement[-eval_count:]),
        max_boundary_displacement=_finite_max(max_boundary_displacement),
        mean_signed_boundary_displacement=_finite_mean(mean_signed_boundary_displacement),
        boundary_roughness_change=final_roughness - initial_roughness,
        solidity_change=final_solidity - initial_solidity,
        solidity_ratio=_safe_ratio(final_solidity, initial_solidity),
        segmentation_quality_flag=quality_flag,
    )


def analyze_segmentation(
    video: np.ndarray,
    name: str,
    seg_config: SegmentationConfig,
    in_config: ReaderConfig,
    out_config: WriterConfig,
    flow_config: OpticalFlowConfig | None = None,
) -> Tuple[Optional[plt.Figure], SegmentationResults]:
    vprint("Beginning Segmentation / Morphology Analysis")
    frame_indices, frame_step = find_analysis_frames(video, seg_config.frame_step)
    save_spots = {frame_indices[0], frame_indices[int((len(frame_indices) - 1) / 2)], frame_indices[-1]}

    metrics_path = os.path.join(name, "SegmentationMetrics.csv")
    components_path = os.path.join(name, "SegmentationComponents.csv")
    masks_path = os.path.join(name, "SegmentationMasks.csv")

    metrics_file = open(metrics_path, "w", newline="", encoding="utf-8")
    metrics_writer = csv.writer(metrics_file)
    metrics_writer.writerow(PER_FRAME_HEADERS)

    mask_writer, mask_file = None, None
    component_file, component_writer = None, None
    if out_config.save_rds:
        mask_writer, mask_file = setup_csv_writer(masks_path)
        component_file = open(components_path, "w", newline="", encoding="utf-8")
        component_writer = csv.writer(component_file)
        component_writer.writerow(COMPONENT_HEADERS)

    rows = []
    example_frames = []
    reference_mask = None
    try:
        for frame_idx in frame_indices:
            frame = video[frame_idx]
            mask, threshold = segment_frame(frame, seg_config)
            if reference_mask is None:
                reference_mask = mask.copy()
            row, component_rows = _frame_metrics(
                frame_idx,
                frame,
                mask,
                threshold,
                seg_config,
                reference_mask,
                in_config.um_pixel_ratio,
            )
            rows.append(row)
            metrics_writer.writerow(row)

            if out_config.save_rds:
                _write_mask_rds(mask_writer, frame_idx, mask)
                component_writer.writerows(component_rows)

            if out_config.save_visualizations and frame_idx in save_spots:
                _save_overlay(frame, mask, frame_idx, name)
                _save_labeled_components(frame, mask, frame_idx, name)
                example_frames.append((frame_idx, frame.copy(), mask.copy()))
    finally:
        metrics_file.close()
        if mask_file:
            mask_file.close()
        if component_file:
            component_file.close()

    summary = _summarize(rows, seg_config, in_config)

    if seg_config.save_labeled_video:
        _save_labeled_segmentation_video(video, seg_config, name)
    if seg_config.save_component_trajectories:
        _save_component_trajectories(video, seg_config, name)
    if seg_config.save_masked_flow_metrics or seg_config.save_masked_flow_visualizations:
        _save_masked_flow_metrics(video, seg_config, flow_config or OpticalFlowConfig(), in_config, name)

    figure = None
    if out_config.save_visualizations and rows:
        data = np.array([row[:-1] for row in rows], dtype=float)
        frames = data[:, 0]
        centroid_x = data[:, 8]
        centroid_y = data[:, 9]
        mean_boundary_displacement = data[:, 18]
        _save_frame_contact_sheet(example_frames, name)

        figure = _save_timeseries_plot(
            frames,
            mean_boundary_displacement,
            "Frame",
            "Mean Boundary Displacement",
            name,
            "Segmentation Boundary Displacement.png",
        )
        _save_centroid_plot(frames, centroid_x, centroid_y, name)

    return figure, summary
