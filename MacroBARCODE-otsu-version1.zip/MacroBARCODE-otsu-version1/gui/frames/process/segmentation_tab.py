import tkinter as tk
from tkinter import ttk

from gui.config import BarcodeConfigGUI, InputConfigGUI, PreviewConfigGUI
from utils.gui import create_option_section, create_popup


def create_segmentation_frame(
    parent,
    config: BarcodeConfigGUI,
    preview_config: PreviewConfigGUI,
    input_config: InputConfigGUI,
):
    """Create the segmentation / morphology settings tab."""
    frame = ttk.Frame(parent)
    cs = config.segmentation_parameters
    row = 0

    create_option_section(
        frame,
        row,
        cs.invert_segmentation,
        "Invert Segmentation",
        "Treat low-intensity regions as material instead of high-intensity regions.",
    )
    row += 1

    threshold_method_label = tk.Label(frame, text="Threshold Method:")
    threshold_method_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    threshold_method_menu = ttk.Combobox(
        frame,
        textvariable=cs.threshold_method,
        values=["Otsu", "Mean", "Percentile"],
        width=12,
        state="readonly",
    )
    threshold_method_menu.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    create_popup(
        frame,
        "Choose how material/background threshold is estimated for each analyzed frame. Otsu is the default automatic method.",
        row,
        threshold_method_label,
    )
    row += 1

    threshold_offset_label = tk.Label(frame, text="Threshold Offset:")
    threshold_offset_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    threshold_offset_scale = tk.Scale(
        frame,
        from_=-1.0,
        to=1.0,
        resolution=0.025,
        orient="horizontal",
        variable=cs.threshold_offset,
        length=300,
        showvalue=True,
    )
    threshold_offset_scale.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    create_popup(
        frame,
        "Adjust the automatic threshold by multiplying it by 1 + offset.",
        row,
        threshold_offset_label,
    )
    row += 1

    smoothing_label = tk.Label(frame, text="Gaussian Smoothing Sigma:")
    smoothing_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    smoothing_spin = ttk.Spinbox(
        frame, from_=0.0, to=10.0, increment=0.25, textvariable=cs.smoothing_sigma, width=7
    )
    smoothing_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    row += 1

    min_object_label = tk.Label(frame, text="Minimum Object Size:")
    min_object_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    min_object_spin = ttk.Spinbox(
        frame, from_=1, to=100000, increment=1, textvariable=cs.minimum_object_size, width=9
    )
    min_object_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    row += 1

    hole_label = tk.Label(frame, text="Hole Filling Size:")
    hole_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    hole_spin = ttk.Spinbox(
        frame, from_=1, to=100000, increment=1, textvariable=cs.hole_filling_size, width=9
    )
    hole_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    row += 1

    opening_label = tk.Label(frame, text="Opening Radius:")
    opening_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    opening_spin = ttk.Spinbox(
        frame, from_=0, to=25, increment=1, textvariable=cs.opening_size, width=7
    )
    opening_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    row += 1

    closing_label = tk.Label(frame, text="Closing Radius:")
    closing_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    closing_spin = ttk.Spinbox(
        frame, from_=0, to=25, increment=1, textvariable=cs.closing_size, width=7
    )
    closing_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    row += 1

    frame_step_label = tk.Label(frame, text="Frame Step:")
    frame_step_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    frame_step_spin = ttk.Spinbox(
        frame, from_=1, to=100, increment=1, textvariable=cs.frame_step, width=7
    )
    frame_step_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    row += 1

    frame_fraction_label = tk.Label(frame, text="Fraction of Frames Evaluated:")
    frame_fraction_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    frame_fraction_spin = ttk.Spinbox(
        frame,
        from_=0.01,
        to=0.25,
        increment=0.01,
        textvariable=cs.percentage_frames_evaluated,
        format="%.2f",
        width=7,
    )
    frame_fraction_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    row += 1

    min_area_label = tk.Label(frame, text="Minimum Valid Area Fraction:")
    min_area_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    min_area_spin = ttk.Spinbox(
        frame, from_=0.0, to=1.0, increment=0.001, textvariable=cs.min_area_fraction, width=7
    )
    min_area_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    row += 1

    max_area_label = tk.Label(frame, text="Maximum Valid Area Fraction:")
    max_area_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    max_area_spin = ttk.Spinbox(
        frame, from_=0.0, to=1.0, increment=0.001, textvariable=cs.max_area_fraction, width=7
    )
    max_area_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    row += 1

    max_components_label = tk.Label(frame, text="Maximum Valid Components:")
    max_components_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    max_components_spin = ttk.Spinbox(
        frame, from_=1, to=100000, increment=1, textvariable=cs.max_components, width=9
    )
    max_components_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    row += 1

    create_option_section(
        frame,
        row,
        cs.save_labeled_video,
        "Save Labeled Segmentation Video",
        "Save a slow side-by-side video of the original frame, segmentation overlay, and labeled component mask. Component labels are matched frame-to-frame where possible.",
    )
    row += 1

    video_step_label = tk.Label(frame, text="Labeled Video Frame Step:")
    video_step_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    video_step_spin = ttk.Spinbox(
        frame, from_=1, to=100, increment=1, textvariable=cs.labeled_video_frame_step, width=7
    )
    video_step_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    create_popup(
        frame,
        "Choose the interval between frames included in the labeled segmentation video. Default 2 shows every other frame.",
        row,
        video_step_label,
    )
    row += 1

    video_fps_label = tk.Label(frame, text="Labeled Video FPS:")
    video_fps_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    video_fps_spin = ttk.Spinbox(
        frame, from_=0.25, to=30.0, increment=0.25, textvariable=cs.labeled_video_fps, width=7
    )
    video_fps_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    create_popup(
        frame,
        "Frames per second for the labeled segmentation video. Lower values make label changes easier to inspect.",
        row,
        video_fps_label,
    )
    row += 1

    create_option_section(
        frame,
        row,
        cs.save_component_trajectories,
        "Save Component Trajectories",
        "Save a CSV and plot tracking the centroid trajectory of each segmented component using persistent labels.",
    )
    row += 1

    trajectory_step_label = tk.Label(frame, text="Component Trajectory Frame Step:")
    trajectory_step_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    trajectory_step_spin = ttk.Spinbox(
        frame, from_=1, to=100, increment=1, textvariable=cs.component_trajectory_frame_step, width=7
    )
    trajectory_step_spin.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    create_popup(
        frame,
        "Choose the interval between frames used for per-component trajectory tracking.",
        row,
        trajectory_step_label,
    )
    row += 1

    create_option_section(
        frame,
        row,
        cs.save_masked_flow_metrics,
        "Save Masked Flow Metrics",
        "Compute optical-flow metrics inside the segmentation mask and compare them with full-FOV flow values.",
    )
    row += 1

    create_option_section(
        frame,
        row,
        cs.save_masked_flow_visualizations,
        "Save Masked Flow Visualizations",
        "Save first, middle, and final comparison images showing full-FOV optical flow versus mask-only optical flow.",
    )

    return frame
