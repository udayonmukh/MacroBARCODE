"""Stack per-frame TIFF sequences into multipage TIFF files for BARCODE.

Examples:
    python tools/stack_tiff_sequence.py data/Fluo-N2DH-GOWT1/01
    python tools/stack_tiff_sequence.py data/Fluo-N2DH-GOWT1 --recursive --output-dir data/stacked
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import numpy as np
import tifffile


def natural_key(path: Path) -> list[object]:
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r"(\d+)", path.name)]


def sequence_dirs(root: Path, pattern: str, recursive: bool, min_frames: int) -> list[Path]:
    if not recursive:
        return [root]

    dirs = []
    for directory in [root, *[p for p in root.rglob("*") if p.is_dir()]]:
        if len(list(directory.glob(pattern))) >= min_frames:
            dirs.append(directory)
    return dirs


def default_output_name(sequence_dir: Path, root: Path) -> str:
    if sequence_dir == root:
        return f"{sequence_dir.name}_stack.tif"
    parts = sequence_dir.relative_to(root).parts
    return "_".join((root.name, *parts)) + ".tif"


def stack_sequence(sequence_dir: Path, output_path: Path, pattern: str, limit_frames: int | None) -> None:
    frame_paths = sorted(sequence_dir.glob(pattern), key=natural_key)
    if limit_frames is not None:
        frame_paths = frame_paths[:limit_frames]
    if not frame_paths:
        raise ValueError(f"No TIFF frames found in {sequence_dir}")

    first = tifffile.imread(frame_paths[0])
    frames = np.empty((len(frame_paths), *first.shape), dtype=first.dtype)
    frames[0] = first

    for index, frame_path in enumerate(frame_paths[1:], start=1):
        frame = tifffile.imread(frame_path)
        if frame.shape != first.shape:
            raise ValueError(
                f"Frame shape mismatch in {sequence_dir}: "
                f"{frame_path.name} has {frame.shape}, expected {first.shape}"
            )
        frames[index] = frame

    output_path.parent.mkdir(parents=True, exist_ok=True)
    tifffile.imwrite(output_path, frames)
    print(f"Wrote {output_path}  shape={frames.shape}  dtype={frames.dtype}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Frame folder, or dataset root when using --recursive.")
    parser.add_argument("--output-dir", type=Path, default=None, help="Directory for stacked TIFF files.")
    parser.add_argument("--output", type=Path, default=None, help="Output file for a single sequence.")
    parser.add_argument("--pattern", default="*.tif", help="Frame filename pattern, e.g. '*.tif' or 't*.tif'.")
    parser.add_argument("--recursive", action="store_true", help="Stack every subfolder that contains TIFF frames.")
    parser.add_argument("--min-frames", type=int, default=2, help="Minimum frames required for recursive mode.")
    parser.add_argument("--limit-frames", type=int, default=None, help="Optional first-N frame limit for quick tests.")
    args = parser.parse_args()

    root = args.input.resolve()
    if not root.is_dir():
        raise ValueError(f"Input must be a directory: {root}")

    dirs = sequence_dirs(root, args.pattern, args.recursive, args.min_frames)
    if args.output is not None and len(dirs) != 1:
        raise ValueError("--output can only be used for a single sequence. Use --output-dir with --recursive.")

    for directory in dirs:
        if args.output is not None:
            output_path = args.output.resolve()
        else:
            output_dir = args.output_dir.resolve() if args.output_dir else directory.parent
            output_path = output_dir / default_output_name(directory, root)
        stack_sequence(directory, output_path, args.pattern, args.limit_frames)


if __name__ == "__main__":
    main()
