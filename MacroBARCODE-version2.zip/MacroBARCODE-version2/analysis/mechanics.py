"""Optional mechanics and crack-analysis helpers for segmentation masks."""

from __future__ import annotations

import heapq

import cv2
import numpy as np
from skimage.morphology import skeletonize


def as_uint8(frame: np.ndarray) -> np.ndarray:
    """Robustly map a two-dimensional microscopy frame to uint8."""
    data = np.asarray(frame)
    if data.ndim != 2:
        raise ValueError("Mechanics analysis expects a two-dimensional channel frame")
    finite = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0)
    if finite.dtype == np.uint8:
        return finite.copy()
    low, high = np.percentile(finite, (0.5, 99.5))
    if high <= low:
        return np.zeros(finite.shape, dtype=np.uint8)
    return np.clip((finite - low) * (255.0 / (high - low)), 0, 255).astype(np.uint8)


def boundary_from_mask(
    mask: np.ndarray,
    fallback_frame: np.ndarray | None = None,
    canny_low: int = 50,
    canny_high: int = 150,
) -> tuple[np.ndarray, bool]:
    """Extract a one-pixel exterior contour, using Canny only when the mask is empty."""
    binary = (np.asarray(mask) > 0).astype(np.uint8) * 255
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    boundary = np.zeros_like(binary)
    if contours:
        cv2.drawContours(boundary, contours, -1, 255, 1)
        return boundary, False
    if fallback_frame is None:
        return boundary, False
    return cv2.Canny(as_uint8(fallback_frame), canny_low, canny_high), True


def boundary_overlay(frame: np.ndarray, boundary: np.ndarray) -> np.ndarray:
    """Return an RGB evidence image with boundaries shown in red."""
    gray = as_uint8(frame)
    overlay = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
    overlay[np.asarray(boundary) > 0] = (255, 0, 0)
    return overlay


def segmentation_qc(
    mask: np.ndarray,
    confidence: np.ndarray | None = None,
    used_canny_fallback: bool = False,
) -> dict[str, float]:
    """Compute interpretable mask confidence and quality-control indicators."""
    binary = (np.asarray(mask) > 0).astype(np.uint8)
    foreground = binary.astype(bool)
    if confidence is None:
        confidence = np.ones(binary.shape, dtype=np.float32)
    confidence_mean = float(np.mean(confidence[foreground])) if foreground.any() else 0.0
    component_count = max(0, cv2.connectedComponents(binary, connectivity=8)[0] - 1)
    touches_border = bool(
        np.any(binary[0])
        or np.any(binary[-1])
        or np.any(binary[:, 0])
        or np.any(binary[:, -1])
    )
    foreground_fraction = float(np.mean(binary))
    qc_score = confidence_mean
    if foreground_fraction < 0.001 or foreground_fraction > 0.999:
        qc_score *= 0.25
    if touches_border:
        qc_score *= 0.8
    if used_canny_fallback:
        qc_score *= 0.5
    return {
        "confidence": confidence_mean,
        "qc_score": float(np.clip(qc_score, 0.0, 1.0)),
        "foreground_fraction": foreground_fraction,
        "component_count": float(component_count),
        "touches_border": float(touches_border),
        "canny_fallback": float(used_canny_fallback),
    }


def largest_contour(mask: np.ndarray) -> np.ndarray | None:
    contours, _ = cv2.findContours(
        (np.asarray(mask) > 0).astype(np.uint8),
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_NONE,
    )
    return max(contours, key=cv2.contourArea) if contours else None


def contour_metrics(mask: np.ndarray, pixel_size: float = 1.0) -> tuple[list[np.ndarray], dict[str, float]]:
    """Extract exterior contours and measure physical arc length."""
    contours, _ = cv2.findContours(
        (np.asarray(mask) > 0).astype(np.uint8),
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_NONE,
    )
    lengths = np.asarray(
        [cv2.arcLength(contour, True) * pixel_size for contour in contours],
        dtype=float,
    )
    return contours, {
        "contour_count": float(len(contours)),
        "total_contour_length": float(np.sum(lengths)) if len(lengths) else 0.0,
        "mean_contour_length": float(np.mean(lengths)) if len(lengths) else 0.0,
        "max_contour_length": float(np.max(lengths)) if len(lengths) else 0.0,
    }


def pack_contours(contours: list[np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
    """Pack variable-length contour coordinates into numeric arrays."""
    lengths = np.asarray([len(contour) for contour in contours], dtype=np.int32)
    offsets = np.concatenate(([0], np.cumsum(lengths))).astype(np.int32)
    if contours:
        points = np.concatenate([contour[:, 0, :] for contour in contours]).astype(np.int32)
    else:
        points = np.empty((0, 2), dtype=np.int32)
    return points, offsets


def contour_curvature(mask: np.ndarray, pixel_size: float = 1.0) -> tuple[np.ndarray, dict[str, float]]:
    """Compute signed d(theta)/ds curvature along the largest closed contour."""
    contour = largest_contour(mask)
    curvature_map = np.zeros(np.asarray(mask).shape, dtype=np.float32)
    if contour is None or len(contour) < 5:
        return curvature_map, {
            "mean_signed_curvature": np.nan,
            "mean_absolute_curvature": np.nan,
            "max_absolute_curvature": np.nan,
        }
    points = contour[:, 0, :].astype(np.float64) * pixel_size
    first = (np.roll(points, -1, axis=0) - np.roll(points, 1, axis=0)) / 2.0
    second = np.roll(points, -1, axis=0) - 2.0 * points + np.roll(points, 1, axis=0)
    denominator = np.power(first[:, 0] ** 2 + first[:, 1] ** 2, 1.5)
    numerator = first[:, 0] * second[:, 1] - first[:, 1] * second[:, 0]
    values = np.divide(
        numerator,
        denominator,
        out=np.zeros_like(numerator),
        where=denominator > 1e-12,
    )
    coordinates = contour[:, 0, :]
    curvature_map[coordinates[:, 1], coordinates[:, 0]] = values.astype(np.float32)
    return curvature_map, {
        "mean_signed_curvature": float(np.mean(values)),
        "mean_absolute_curvature": float(np.mean(np.abs(values))),
        "max_absolute_curvature": float(np.max(np.abs(values))),
    }


def shape_descriptors(mask: np.ndarray, pixel_size: float = 1.0) -> dict[str, float]:
    """Measure area, perimeter, circularity, elongation, and orientation."""
    contour = largest_contour(mask)
    if contour is None:
        return {key: np.nan for key in ("area", "perimeter", "circularity", "elongation", "angle")}
    area = float(cv2.contourArea(contour) * pixel_size**2)
    perimeter = float(cv2.arcLength(contour, True) * pixel_size)
    circularity = float(4.0 * np.pi * area / perimeter**2) if perimeter > 0 else np.nan
    if len(contour) >= 5:
        (_, _), axes, angle = cv2.fitEllipse(contour)
        major, minor = max(axes), min(axes)
    else:
        (_, _), axes, angle = cv2.minAreaRect(contour)
        major, minor = max(axes), min(axes)
    elongation = float(major / minor) if minor > 0 else np.nan
    return {
        "area": area,
        "perimeter": perimeter,
        "circularity": circularity,
        "elongation": elongation,
        "angle": float(angle),
    }


def normalized_shape_change(records: list[dict[str, float]]) -> dict[str, np.ndarray]:
    """Return normalized delta time series relative to the first valid frame."""
    output: dict[str, np.ndarray] = {}
    for key in ("area", "perimeter", "circularity", "elongation", "angle"):
        values = np.asarray([record[key] for record in records], dtype=float)
        finite = np.flatnonzero(np.isfinite(values))
        if not len(finite):
            output[key] = np.full_like(values, np.nan)
            continue
        baseline = values[finite[0]]
        if key == "angle":
            delta = (values - baseline + 90.0) % 180.0 - 90.0
            output[key] = delta / 180.0
        else:
            scale = abs(baseline)
            output[key] = (values - baseline) / scale if scale > 1e-12 else values - baseline
    return output


def displacement_field(
    previous: np.ndarray,
    current: np.ndarray,
    method: str = "flow",
    window_size: int = 32,
    pixel_size: float = 1.0,
) -> np.ndarray:
    """Estimate dense displacement by Farneback flow or rigid registration."""
    before, after = as_uint8(previous), as_uint8(current)
    if before.shape != after.shape:
        raise ValueError("Deformation frames must have the same shape")
    if method == "registration":
        shift, _ = cv2.phaseCorrelate(before.astype(np.float32), after.astype(np.float32))
        field = np.empty((*before.shape, 2), dtype=np.float32)
        field[..., 0], field[..., 1] = shift
    elif method == "flow":
        field = cv2.calcOpticalFlowFarneback(
            before,
            after,
            None,
            0.5,
            3,
            window_size,
            3,
            5,
            1.2,
            0,
        )
    else:
        raise ValueError("Deformation method must be flow or registration")
    return field.astype(np.float32) * pixel_size


def curl_map(displacement: np.ndarray, spacing: float = 1.0) -> np.ndarray:
    """Compute signed two-dimensional curl dv/dx - du/dy."""
    field = np.asarray(displacement, dtype=float)
    if field.ndim != 3 or field.shape[2] != 2:
        raise ValueError("Displacement must have shape (height, width, 2)")
    du_dy, _ = np.gradient(field[..., 0], spacing, spacing)
    _, dv_dx = np.gradient(field[..., 1], spacing, spacing)
    return (dv_dx - du_dy).astype(np.float32)


def strain_tensor(
    displacement: np.ndarray,
    spacing: float = 1.0,
    finite: bool = False,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute small-strain or Green-Lagrange finite-strain tensor maps."""
    field = np.asarray(displacement, dtype=float)
    if field.ndim != 3 or field.shape[2] != 2:
        raise ValueError("Displacement must have shape (height, width, 2)")
    du_dy, du_dx = np.gradient(field[..., 0], spacing, spacing)
    dv_dy, dv_dx = np.gradient(field[..., 1], spacing, spacing)
    if finite:
        exx = du_dx + 0.5 * (du_dx**2 + dv_dx**2)
        eyy = dv_dy + 0.5 * (du_dy**2 + dv_dy**2)
        exy = 0.5 * (du_dy + dv_dx + du_dx * du_dy + dv_dx * dv_dy)
    else:
        exx = du_dx
        eyy = dv_dy
        exy = 0.5 * (du_dy + dv_dx)
    return exx.astype(np.float32), eyy.astype(np.float32), exy.astype(np.float32)


_NEIGHBORS = (
    (-1, -1, np.sqrt(2.0)), (-1, 0, 1.0), (-1, 1, np.sqrt(2.0)),
    (0, -1, 1.0), (0, 1, 1.0),
    (1, -1, np.sqrt(2.0)), (1, 0, 1.0), (1, 1, np.sqrt(2.0)),
)


def _skeleton_graph(skeleton: np.ndarray) -> tuple[dict[tuple[int, int], list], dict]:
    pixels = {tuple(point) for point in np.argwhere(skeleton)}
    graph: dict[tuple[int, int], list[tuple[tuple[int, int], float]]] = {}
    degree = {}
    for y, x in pixels:
        neighbors = []
        for dy, dx, weight in _NEIGHBORS:
            candidate = (y + dy, x + dx)
            if candidate in pixels:
                neighbors.append((candidate, weight))
        graph[(y, x)] = neighbors
        degree[(y, x)] = len(neighbors)
    return graph, degree


def _dijkstra_farthest(graph: dict, start: tuple[int, int]) -> tuple[tuple[int, int], float]:
    distances = {start: 0.0}
    queue = [(0.0, start)]
    farthest = start
    while queue:
        distance, node = heapq.heappop(queue)
        if distance != distances[node]:
            continue
        if distance > distances[farthest]:
            farthest = node
        for neighbor, weight in graph[node]:
            candidate = distance + weight
            if candidate < distances.get(neighbor, np.inf):
                distances[neighbor] = candidate
                heapq.heappush(queue, (candidate, neighbor))
    return farthest, distances[farthest]


def crack_metrics(mask: np.ndarray, pixel_size: float = 1.0) -> tuple[np.ndarray, dict]:
    """Measure skeleton length and local crack width from a binary crack mask."""
    binary = (np.asarray(mask) > 0).astype(np.uint8)
    skeleton = skeletonize(binary > 0)
    distance = cv2.distanceTransform(binary, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
    width_map = np.zeros(binary.shape, dtype=np.float32)
    width_map[skeleton] = 2.0 * distance[skeleton] * pixel_size
    widths = width_map[skeleton]
    graph, degree = _skeleton_graph(skeleton)
    if not graph:
        return skeleton.astype(np.uint8), {
            "length": 0.0,
            "longest_path": 0.0,
            "branch_count": 0,
            "tip_count": 0,
            "tips": [],
            "mean_width": 0.0,
            "max_width": 0.0,
            "width_map": width_map,
        }
    total = sum(weight for edges in graph.values() for _, weight in edges) / 2.0
    tips = [node for node, value in degree.items() if value == 1]
    branch_mask = np.zeros_like(skeleton, dtype=np.uint8)
    for node, value in degree.items():
        if value > 2:
            branch_mask[node] = 1
    branch_count = max(0, cv2.connectedComponents(branch_mask, connectivity=8)[0] - 1)
    candidates = tips or [next(iter(graph))]
    longest = 0.0
    for tip in candidates:
        _, distance_value = _dijkstra_farthest(graph, tip)
        longest = max(longest, distance_value)
    tips_xy = [(int(x), int(y)) for y, x in tips]
    return skeleton.astype(np.uint8), {
        "length": float(total * pixel_size),
        "longest_path": float(longest * pixel_size),
        "branch_count": int(branch_count),
        "tip_count": len(tips_xy),
        "tips": tips_xy,
        "mean_width": float(np.mean(widths)) if len(widths) else 0.0,
        "max_width": float(np.max(widths)) if len(widths) else 0.0,
        "width_map": width_map,
    }


def track_crack_tips(
    previous_tips: list[tuple[int, int]],
    current_tips: list[tuple[int, int]],
    pixel_size: float = 1.0,
) -> dict[str, float]:
    """Track tips by nearest neighbor and summarize their displacement."""
    if not previous_tips or not current_tips:
        return {"mean_tip_displacement": np.nan, "max_tip_displacement": np.nan}
    previous = np.asarray(previous_tips, dtype=float)
    current = np.asarray(current_tips, dtype=float)
    distances = np.linalg.norm(previous[:, None, :] - current[None, :, :], axis=2)
    nearest = np.min(distances, axis=1) * pixel_size
    return {
        "mean_tip_displacement": float(np.mean(nearest)),
        "max_tip_displacement": float(np.max(nearest)),
    }
