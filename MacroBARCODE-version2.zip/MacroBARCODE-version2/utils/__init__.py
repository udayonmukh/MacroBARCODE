from utils.timing import Timer
import numpy as np
# Global verbose setting
_VERBOSE = False

def set_verbose(verbose: bool):
    """Set global verbose mode."""
    global _VERBOSE
    _VERBOSE = verbose

def vprint(*args, **kwargs):
    """Global verbose print function."""
    if _VERBOSE:
        print(*args, **kwargs, flush=True)

class MyException(Exception):
    pass

def groupAvg(arr, N):
    result = np.cumsum(arr, 0)[N-1::N]/float(N)
    result = np.cumsum(result, 1)[:,N-1::N]/float(N)
    result[1:] = result[1:] - result[:-1]
    result[:,1:] = result[:,1:] - result[:,:-1]
    return result

def average_largest(lst, percent = 0.1):
    new_lst = sorted(lst, reverse=True)
    length = len(new_lst)
    top_percent = int(np.ceil(length * percent))
    return np.nanmean(new_lst[0:top_percent])

def flatten(xss):
    return np.array([x for xs in xss for x in xs])

def find_analysis_frames(file, step_size):
    image_length = len(file)
    while step_size >= image_length:
        step_size /= 5
        vprint(f'Step size between frames too large for analysis, new step size set to {step_size}')
    frame_indices = list(range(0, image_length, step_size))
    if frame_indices[-1] != image_length - 1:
        frame_indices.append(image_length - 1)
    return frame_indices, step_size

def check_channel_dim(image):
    min_intensity = np.min(image)
    mean_intensity = np.mean(image)
    return 2 * np.exp(-1) * mean_intensity <= min_intensity

__all__ = [
    "Timer",
    "vprint",
    "set_verbose",
]