import os
import tkinter as tk
from tkinter import ttk

import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from skimage import measure

from analysis.mechanics import crack_metrics
from analysis.segmentation import (
    _boundary_roughness,
    _quality_flags,
    _whole_mask_solidity,
    segment_frame,
)
from gui.config import BarcodeConfigGUI, InputConfigGUI, PreviewConfigGUI
from utils.gui import create_option_section, create_popup


def _add_spinbox(frame, row, label_text, variable, from_, to, increment, width=7, help_text=None, fmt=None):
    label = tk.Label(frame, text=label_text)
    label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    options = {
        "from_": from_,
        "to": to,
        "increment": increment,
        "textvariable": variable,
        "width": width,
    }
    if fmt is not None:
        options["format"] = fmt
    spinbox = ttk.Spinbox(frame, **options)
    spinbox.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    if help_text:
        create_popup(frame, help_text, row, label)
    return spinbox


def create_segmentation_frame(
    parent,
    config: BarcodeConfigGUI,
    preview_config: PreviewConfigGUI,
    input_config: InputConfigGUI,
):
    """Create the segmentation / morphology settings tab with live preview."""
    frame = ttk.Frame(parent)
    cs = config.segmentation_parameters
    cp = preview_config
    ci = input_config
    row = 0

    create_option_section(
        frame,
        row,
        cs.invert_segmentation,
        "Invert Segmentation",
        "Treat low-intensity regions as material instead of high-intensity regions.",
    )
    row += 1

    method_label = tk.Label(frame, text="Threshold / Segmentation Method:")
    method_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    method_menu = ttk.Combobox(
        frame,
        textvariable=cs.threshold_method,
        values=["Otsu", "Mean", "Percentile", "Adaptive", "Canny"],
        width=12,
        state="readonly",
    )
    method_menu.grid(row=row, column=1, sticky="w", padx=5, pady=5)
    create_popup(
        frame,
        "Choose how material/background masks are generated. Otsu is the default automatic method; Adaptive helps with uneven illumination; Canny fills closed edge contours.",
        row,
        method_label,
    )
    row += 1

    threshold_frame = ttk.Frame(frame)
    threshold_frame.grid(row=row, column=0, columnspan=3, sticky="ew")
    threshold_offset_label = tk.Label(threshold_frame, text="Threshold Offset:")
    threshold_offset_label.grid(row=0, column=0, sticky="w", padx=5, pady=5)
    tk.Scale(
        threshold_frame,
        from_=-1.0,
        to=1.0,
        resolution=0.025,
        orient="horizontal",
        variable=cs.threshold_offset,
        length=300,
        showvalue=True,
    ).grid(row=0, column=1, sticky="w", padx=5, pady=5)
    create_popup(
        threshold_frame,
        "For Otsu/Mean/Percentile only: multiply the automatic segmentation threshold by 1 + offset.",
        0,
        threshold_offset_label,
    )
    row += 1

    adaptive_frame = ttk.Frame(frame)
    adaptive_frame.grid(row=row, column=0, columnspan=3, sticky="ew")
    tk.Label(adaptive_frame, text="Adaptive Block Size:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
    ttk.Combobox(
        adaptive_frame,
        textvariable=cs.adaptive_block_size,
        values=tuple(range(3, 102, 2)),
        state="readonly",
        width=8,
    ).grid(row=0, column=1, sticky="w", padx=5, pady=5)
    tk.Label(adaptive_frame, text="Adaptive C:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
    tk.Scale(
        adaptive_frame,
        from_=-32,
        to=32,
        resolution=0.5,
        orient="horizontal",
        variable=cs.adaptive_c,
        length=300,
        showvalue=True,
    ).grid(row=1, column=1, sticky="w", padx=5, pady=5)
    row += 1

    canny_frame = ttk.LabelFrame(frame, text="Advanced Canny Settings")
    canny_frame.grid(row=row, column=0, columnspan=3, sticky="ew", padx=5, pady=5)
    tk.Label(canny_frame, text="Canny Lower Threshold:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
    tk.Scale(
        canny_frame,
        from_=0,
        to=254,
        resolution=1,
        orient="horizontal",
        variable=cs.canny_low,
        length=300,
        showvalue=True,
    ).grid(row=0, column=1, sticky="w", padx=5, pady=5)
    tk.Label(canny_frame, text="Canny Upper Threshold:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
    tk.Scale(
        canny_frame,
        from_=1,
        to=255,
        resolution=1,
        orient="horizontal",
        variable=cs.canny_high,
        length=300,
        showvalue=True,
    ).grid(row=1, column=1, sticky="w", padx=5, pady=5)
    row += 1

    _add_spinbox(
        frame,
        row,
        "Gaussian Smoothing Sigma:",
        cs.smoothing_sigma,
        0.0,
        10.0,
        0.25,
        help_text="Smooth the frame before thresholding. Higher values reduce noise but can blur small structures.",
    )
    row += 1

    _add_spinbox(
        frame,
        row,
        "Minimum Object Size:",
        cs.minimum_object_size,
        1,
        100000,
        1,
        width=9,
        help_text="Remove connected material regions smaller than this pixel area.",
    )
    row += 1

    _add_spinbox(frame, row, "Frame Step:", cs.frame_step, 1, 100, 1)
    row += 1
    _add_spinbox(
        frame,
        row,
        "Fraction of Frames Evaluated:",
        cs.percentage_frames_evaluated,
        0.01,
        0.25,
        0.01,
        fmt="%.2f",
    )
    row += 1

    preview_label = tk.Label(frame, text="Preview Frame:")
    preview_label.grid(row=row, column=0, sticky="w", padx=5, pady=5)
    preview_slider = tk.Scale(
        frame,
        from_=0,
        to=0,
        resolution=1,
        orient="horizontal",
        variable=cp.preview_frame_number,
        length=300,
    )
    preview_slider.grid(row=row, column=1, sticky="ew", padx=5, pady=5)
    row += 1

    tk.Label(frame, text="Preview File:").grid(row=row, column=0, sticky="w", padx=5, pady=5)
    sample_files = ttk.Combobox(frame, textvariable=cp.sample_file, state="disabled", width=45)
    sample_files.grid(row=row, column=1, columnspan=2, sticky="ew", padx=5, pady=5)
    row += 1

    tk.Label(frame, text="Original").grid(row=row, column=0, pady=(10, 2))
    tk.Label(frame, text="Boundary Overlay").grid(row=row, column=1, pady=(10, 2))
    tk.Label(frame, text="Filled / Labeled Mask").grid(row=row, column=2, pady=(10, 2))
    row += 1

    root = parent.winfo_toplevel()
    red, green, blue = root.winfo_rgb(root.cget("bg"))
    background = (red / 65535, green / 65535, blue / 65535)
    axes = []
    canvases = []
    for column in range(3):
        figure = Figure(figsize=(3, 3), facecolor=background)
        axis = figure.add_subplot(111)
        axis.axis("off")
        canvas = FigureCanvasTkAgg(figure, master=frame)
        canvas.get_tk_widget().grid(row=row, column=column, padx=4, pady=4)
        axes.append(axis)
        canvases.append(canvas)
    row += 1

    status = tk.Label(
        frame,
        text="Choose a file in Execution Settings to start the live preview.",
        anchor="w",
        justify="left",
    )
    status.grid(row=row, column=0, columnspan=3, sticky="ew", padx=5, pady=5)
    row += 1

    create_option_section(
        frame,
        row,
        cs.save_labeled_video,
        "Save Labeled Segmentation Video",
        "Save a slow side-by-side video of the original frame, segmentation overlay, and labeled component mask.",
    )
    row += 1
    _add_spinbox(frame, row, "Labeled Video Frame Step:", cs.labeled_video_frame_step, 1, 100, 1)
    row += 1
    _add_spinbox(frame, row, "Labeled Video FPS:", cs.labeled_video_fps, 0.25, 30.0, 0.25)
    row += 1

    create_option_section(
        frame,
        row,
        cs.save_component_trajectories,
        "Save Component Trajectories",
        "Save a CSV and plot tracking the centroid trajectory of each segmented component using persistent labels.",
    )
    row += 1
    _add_spinbox(frame, row, "Component Trajectory Frame Step:", cs.component_trajectory_frame_step, 1, 100, 1)
    row += 1

    create_option_section(
        frame,
        row,
        cs.save_masked_flow_metrics,
        "Save Masked Flow Metrics",
        "Compute optical-flow metrics inside the segmentation mask and compare them with full-FOV flow values.",
    )
    row += 1
    create_option_section(
        frame,
        row,
        cs.save_masked_flow_visualizations,
        "Save Masked Flow Visualizations",
        "Save first, middle, and final comparison images showing full-FOV optical flow versus mask-only optical flow.",
    )
    row += 1

    mechanics_frame = ttk.LabelFrame(frame, text="Optional Mechanics / Crack Analysis")
    mechanics_frame.grid(row=row, column=0, columnspan=3, sticky="ew", padx=5, pady=8)
    create_option_section(
        mechanics_frame,
        0,
        cs.enable_mechanics_crack_analysis,
        "Enable Mechanics / Crack Analysis",
        "Save optional MechanicsTimeSeries.csv, MechanicsPairMetrics.csv, and mechanics evidence files. These metrics are not added to the main BARCODE summary.",
    )
    mechanics_options_frame = ttk.Frame(mechanics_frame)
    mechanics_options_frame.grid(row=1, column=0, columnspan=3, sticky="ew", padx=(20, 0))
    create_option_section(
        mechanics_options_frame,
        0,
        cs.crack_invert_mask,
        "Treat Mask Background as Crack Network",
        "Use the background outside the material mask as the crack network for optional skeleton measurements.",
    )
    tk.Label(mechanics_options_frame, text="Deformation Method:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
    ttk.Combobox(
        mechanics_options_frame,
        textvariable=cs.deformation_method,
        values=("flow", "registration"),
        state="readonly",
        width=12,
    ).grid(row=1, column=1, sticky="w", padx=5, pady=5)
    tk.Label(mechanics_options_frame, text="Deformation Window:").grid(row=2, column=0, sticky="w", padx=5, pady=5)
    ttk.Combobox(
        mechanics_options_frame,
        textvariable=cs.deformation_window,
        values=(4, 8, 16, 32, 64, 128),
        state="readonly",
        width=8,
    ).grid(row=2, column=1, sticky="w", padx=5, pady=5)
    tk.Label(mechanics_options_frame, text="Strain Tensor:").grid(row=3, column=0, sticky="w", padx=5, pady=5)
    ttk.Combobox(
        mechanics_options_frame,
        textvariable=cs.strain_type,
        values=("small", "finite"),
        state="readonly",
        width=12,
    ).grid(row=3, column=1, sticky="w", padx=5, pady=5)

    preview_data = {"frame": None, "job": None}

    def set_method_visibility(*_args):
        method = cs.threshold_method.get().lower()
        if method in {"otsu", "mean", "percentile"}:
            threshold_frame.grid()
        else:
            threshold_frame.grid_remove()
        if method == "adaptive":
            adaptive_frame.grid()
        else:
            adaptive_frame.grid_remove()
        if method == "canny":
            canny_frame.grid()
        else:
            canny_frame.grid_remove()

    def set_mechanics_visibility(*_args):
        if cs.enable_mechanics_crack_analysis.get():
            mechanics_options_frame.grid()
        else:
            mechanics_options_frame.grid_remove()

    def clear_preview(message):
        for axis, canvas in zip(axes, canvases):
            axis.clear()
            axis.axis("off")
            canvas.draw_idle()
        status.config(text=message)

    def render_preview():
        preview_data["job"] = None
        image = preview_data["frame"]
        if image is None:
            clear_preview("Choose a file in Execution Settings to start the live preview.")
            return
        try:
            current_config = cs.config
            mask, threshold = segment_frame(image, current_config)
            labeled = measure.label(mask, connectivity=2)
            props = list(measure.regionprops(labeled))
            contours = measure.find_contours(mask.astype(float), 0.5)
            label_image = np.zeros(mask.shape + (3,), dtype=float)
            for label_value in np.unique(labeled):
                if label_value == 0:
                    continue
                rng = np.random.default_rng(int(label_value))
                label_image[labeled == label_value] = rng.uniform(0.20, 0.95, size=3)
        except (tk.TclError, ValueError) as error:
            clear_preview(f"Adjust segmentation parameters: {error}")
            return

        display_scale = max(1, int(np.ceil(max(image.shape) / 500)))
        axes[0].clear()
        axes[0].imshow(image[::display_scale, ::display_scale], cmap="gray", interpolation="nearest")
        axes[0].axis("off")

        axes[1].clear()
        axes[1].imshow(image[::display_scale, ::display_scale], cmap="gray", interpolation="nearest")
        for contour in contours:
            axes[1].plot(contour[:, 1] / display_scale, contour[:, 0] / display_scale, color="cyan", linewidth=1.0)
        axes[1].axis("off")

        axes[2].clear()
        axes[2].imshow(label_image[::display_scale, ::display_scale], interpolation="nearest")
        axes[2].axis("off")

        for canvas in canvases:
            canvas.figure.tight_layout(pad=0.1)
            canvas.draw_idle()

        area_fraction = float(np.sum(mask) / mask.size) if mask.size else np.nan
        total_perimeter = float(np.nansum([prop.perimeter for prop in props])) if props else 0.0
        total_area = float(np.sum(mask))
        edge_concentration = float(total_perimeter / total_area) if total_area > 0 else np.nan
        largest = max(props, key=lambda prop: prop.area) if props else None
        roughness = _boundary_roughness(largest.image, float(largest.perimeter)) if largest else np.nan
        solidity = _whole_mask_solidity(mask)
        touches_border = int(np.any(mask[0]) or np.any(mask[-1]) or np.any(mask[:, 0]) or np.any(mask[:, -1])) if mask.size else 0
        flags = _quality_flags(area_fraction, len(props), touches_border, threshold, image, current_config)
        status_text = (
            f"Area fraction: {area_fraction:.3f}    "
            f"Components: {len(props)}    "
            f"Boundary length: {total_perimeter:.1f} px    "
            f"Edge conc.: {edge_concentration:.4f} 1/px    "
            f"Solidity: {solidity:.3f}    "
            f"Roughness: {roughness:.3f}    "
            f"QC: {flags}"
        )
        if current_config.enable_mechanics_crack_analysis:
            crack_mask = ~mask if current_config.crack_invert_mask else mask
            _, crack = crack_metrics(crack_mask)
            status_text += (
                f"\nCrack length: {crack['length']:.1f} px    "
                f"Branches: {crack['branch_count']}    "
                f"Tips: {crack['tip_count']}    "
                f"Mean/max width: {crack['mean_width']:.2f}/{crack['max_width']:.2f} px"
            )
        status.config(text=status_text)

    def schedule_preview(*_args):
        set_method_visibility()
        if preview_data["job"] is not None:
            frame.after_cancel(preview_data["job"])
        preview_data["job"] = frame.after(100, render_preview)

    def load_preview_frame(*_args):
        path = cp.sample_file.get() if ci.mode.get() == "dir" else ci.file_path.get()
        if ci.mode.get() != "dir" and path and cp.sample_file.get() != path:
            cp.sample_file.set(path)
            return
        if not path:
            preview_data["frame"] = None
            schedule_preview()
            return
        try:
            data = cp.sample_preview
            if data is None or len(data) == 0:
                raise ValueError("the selected file contains no preview frames")
            preview_slider.config(to=max(0, len(data) - 1))
            frame_index = min(max(0, cp.preview_frame_number.get()), len(data) - 1)
            channel = 0 if config.channels.parse_all_channels.get() else config.channels.selected_channel.get()
            channel %= data.shape[3]
            preview_data["frame"] = data[frame_index, :, :, channel]
            schedule_preview()
        except Exception as error:
            preview_data["frame"] = None
            clear_preview(f"Unable to load preview: {error}")

    def update_sample_file_options(*_args):
        directory = ci.dir_path.get()
        if directory and os.path.isdir(directory):
            files = sorted(
                os.path.join(root_path, filename)
                for root_path, _, filenames in os.walk(directory)
                for filename in filenames
                if filename.lower().endswith((".tif", ".tiff", ".nd2", ".avi", ".mp4"))
            )
            sample_files["values"] = files
            sample_files.config(state="readonly" if files else "disabled")
            if files and cp.sample_file.get() not in files:
                cp.sample_file.set(files[0])
        else:
            sample_files.set("")
            sample_files["values"] = []
            sample_files.config(state="disabled")

    ci.file_path.trace_add("write", load_preview_frame)
    ci.dir_path.trace_add("write", update_sample_file_options)
    cp.sample_file.trace_add("write", load_preview_frame)
    cp.preview_frame_number.trace_add("write", load_preview_frame)
    config.channels.selected_channel.trace_add("write", load_preview_frame)
    config.channels.parse_all_channels.trace_add("write", load_preview_frame)
    for variable in (
        cs.invert_segmentation,
        cs.threshold_method,
        cs.threshold_offset,
        cs.adaptive_block_size,
        cs.adaptive_c,
        cs.canny_low,
        cs.canny_high,
        cs.smoothing_sigma,
        cs.minimum_object_size,
        cs.crack_invert_mask,
    ):
        variable.trace_add("write", schedule_preview)
    cs.enable_mechanics_crack_analysis.trace_add("write", set_mechanics_visibility)
    cs.enable_mechanics_crack_analysis.trace_add("write", schedule_preview)

    set_method_visibility()
    set_mechanics_visibility()
    update_sample_file_options()
    load_preview_frame()
    return frame
